#!/bin/bash
depsoft=(gcc
        gcc-c++
        openssl-devel
	ncurses-devel
	perl-Data-Dumper
	libaio-devel
        )
softdir=/opt/software
for soft in ${depsoft[@]}
do
 if [ ! `rpm -qa $soft` ];then
        yum install -y $soft
 fi
done
[ ! -e /opt/local ] && mkdir /opt/local
useradd -M -s /sbin/nologin mysql
tar zxf $softdir/mysql-5.6.30-linux-glibc2.5-x86_64.tar.gz  -C /opt/local/
cd /opt/local
mv mysql-5.6.30-linux-glibc2.5-x86_64 mysql-5.6.30
ln -s mysql-5.6.30 mysql
mkdir -p /opt/local/mysql/{logs,binlog,relaylog}
cp /opt/software/my.cnf /opt/local/mysql/my.cnf
echo -e "basedir=/opt/local/mysql\ndatadir=/opt/local/mysql/data" >> /opt/local/mysql/my.cnf
chown -R mysql. /opt/local/mysql*
cd /opt/local/mysql/scripts
./mysql_install_db --defaults-file=/opt/local/mysql/my.cnf --basedir=/opt/local/mysql --datadir=/opt/local/mysql/data --user=mysql --group=mysql
sed -i 's#^basedir=$#basedir=/opt/local/mysql#g' /opt/local/mysql/support-files/mysql.server
sed -i 's#^datadir=$#datadir=/opt/local/mysql/data#g' /opt/local/mysql/support-files/mysql.server
[ -e /etc/my.cnf ] && rm -rf /etc/my.cnf
cd /opt/local/mysql/support-files/
./mysql.server start 
/opt/local/mysql/bin/mysqladmin -uroot password "xxxxxxxx";
/opt/local/mysql/bin/mysql -uroot -p"xxxxxxxx" -e "use mysql;drop user root@'127.0.0.1';drop user root@'::1';drop user root@'localhost.localdomain';drop user ''@'localhost.localdomain';drop user ''@'localhost';drop database test;select user,host from user; show databases;"
cp /opt/local/mysql/support-files/mysql.server /etc/init.d/mysqld
echo "export PATH=$PATH:/opt/local/mysql/bin" >> /etc/profile
source /etc/profile
chkconfig --add mysqld
chkconfig mysqld on
ss -lnt | grep 3306  && echo -e "\033[31m install ok \033[0m"
